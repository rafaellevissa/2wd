(function() {
	window.Main = {};
	Main.Page = (function() {
		var mosq = null;

		function Page() {
			var _this = this;
			mosq = new Mosquitto();

			$('#connect-button').click(function() {
				return _this.connect();
			});
			$('#disconnect-button').click(function() {
				return _this.disconnect();
			});
			$('#subscribe-button').click(function() {
				return _this.subscribe();
			});
			$('#unsubscribe-button').click(function() {
				return _this.unsubscribe();
			});
			

			mosq.onconnect = function(rc){
				var p = document.createElement("p");

				p.innerHTML = "Conectado ao Broker!";

				$("#debug").append(p);

				mosq.subscribe('direcionais', 0);
				mosq.subscribe("velocidade", 0);
				mosq.subscribe("farois", 0);
				mosq.subscribe("sirene", 0);
				
			};
			mosq.ondisconnect = function(rc){
				var p = document.createElement("p");
				var url = "ws://iot.eclipse.org/ws";
				//var url = "ws://serversmarthouse.duckdns.org:8090/ws";
				
				
				p.innerHTML = "A conexão com o broker foi perdida";
				p.setAttribute('class',"conexao_perdida");

			

				$("#debug").append(p);				
				mosq.connect(url);
			};
			mosq.onmessage = function(topic, payload, qos){
				var p = document.createElement("p");
				var acao = payload[0];

                var img_direcionais = document.querySelector("#img_direcionais"),
                    img_farois = document.querySelector("#img_farois");

				if (acao == "F") {
					console.log('o f chegou');
					img_direcionais.src = "img/frente.png";
				}

				if (acao == "S") {
					console.log('Parado');
					img_direcionais.src = "img/parado.png";
				}

				if (acao == "B") {
					console.log('Parado');
					img_direcionais.src = "img/tras.png";
				}

				if (acao == "L") {
					console.log('Parado');
					img_direcionais.src = "img/esquerda.png";
				}

				if (acao == "R") {
					console.log('Parado');
					img_direcionais.src = "img/direita.png";
				}

				if (acao == "I") {
					console.log('Parado');
					img_direcionais.src = "img/curva_direita.png";
				}

				if (acao == "G") {
					console.log('Parado');
					img_direcionais.src = "img/curva_esquerda.png";
				}

				if (acao == "J") {
					console.log('Parado');
					img_direcionais.src = "img/tras_direira.png";
				}

				if (acao == "H") {
					console.log('Parado');
					img_direcionais.src = "img/tras_esquerda.png";
				}
                
                if (acao == "W") {
					console.log('farol ligado');
				}


				if (acao == "W") {
					console.log('farol ligado');
					img_farois.src = "img/farois_ligados.png";
				}

				if (acao == "w") {
					console.log('farol ligado');
					img_farois.src = "img/farois_desligados.png";
				}

				if (acao == "V") {
					console.log("Sirene ligada");
				}

				if (acao == "v") {
					console.log("Sirene desligada");
				}


				var velo = 0;

				if (topic == "velocidade") {
					velo = Number(acao);

					if (velo == 0) {
						velo = 10;
					}

					if (velo == 1) {
						velo = 20;
					}

					if (velo == 2) {
						velo = 30;
					}

					if (velo == 3) {
						velo = 40;
					}

					if (velo == 4) {
						velo = 50;
					}

					if (velo == 5) {
						velo = 60;
					}

					if (velo == 6) {
						velo = 70;
					}

					if (velo == 7) {
						velo = 80;
					}

					if (velo == 8) {
						velo = 90;
					}

					if (velo == 9) {
						velo = 100;
					}
				}

			    google.charts.load('current', {'packages':['gauge']});
			    google.charts.setOnLoadCallback(drawChart);

			    function drawChart() {

			    var data = google.visualization.arrayToDataTable([
			        ['Label', 'Value'],
			        ['Velocidade', velo],
			    ]);

			    var options = {
			        width: 400, height: 120,
			        redFrom: 90, redTo: 100,
			        yellowFrom:75, yellowTo: 90,
			        minorTicks: 5
			    };

			    var chart = new google.visualization.Gauge(document.getElementById('chart_div'));

			     chart.draw(data, options);
			    }
					//console.log(acao);
					console.log(acao);
				
				$("#status_io").html(p);
			};
		}
		Page.prototype.connect = function(){
			//var url = "ws://iot.eclipse.org/ws";
			mosq.connect("ws://serversmarthouse.duckdns.org:8090/ws");      
		};
		Page.prototype.disconnect = function(){
			mosq.disconnect();
		};


		Page.prototype.subscribe = function(){
			
			mosq.subscribe(topic, 0);
		};


		Page.prototype.unsubscribe = function(){
			var topic = $('#sub-topic-text')[0].value;
			mosq.unsubscribe(topic);
		};
		
		return Page;
	})();
	$(function(){
		return Main.controller = new Main.Page;
	});
}).call(this);